﻿using System;
class Program
{
    static void area_rectangulo(double baseRectangulo, double altura)
    {
        double area = baseRectangulo * altura;
        Console.WriteLine("El area del rectangulo es: " + area);
    }
    static void Main()
    {
        area_rectangulo(5, 3);
    }
}