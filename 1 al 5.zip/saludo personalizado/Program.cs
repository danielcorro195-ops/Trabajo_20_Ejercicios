﻿using System;
class Program
{
    static void saludar(string nombre)
    {
        Console.WriteLine("Hola " + nombre + ", bienvenido!");
    }
    static void Main()
    {
        saludar("Carlos");
    }
}