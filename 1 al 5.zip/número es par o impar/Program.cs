﻿using System;
class Program
{
    static void es_par(int numero)
    {
        if (numero % 2 == 0)
        {
            Console.WriteLine("El numero es par");
        }
        else
        {
            Console.WriteLine("El numero es impar");
        }
    }
    static void Main()
    {
        es_par(7);
    }
}