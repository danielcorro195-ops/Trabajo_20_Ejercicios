﻿using System;
class Program
{
    static void repetir_palabra(string palabra, int veces)
    {
        for (int i = 1; i <= veces; i++)
        {
            Console.WriteLine(palabra);
        }
    }
    static void Main()
    {
        repetir_palabra("Hola", 5);
    }
}