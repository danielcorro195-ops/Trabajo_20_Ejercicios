﻿using System;
class Program
{
    static void tabla_multiplicar(int numero)
    {
        for (int i = 1; i <= 10; i++)
        {
            Console.WriteLine(numero + " x " + i + " = " + (numero * i));
        }
    }
    static void Main()
    {
        tabla_multiplicar(5);
    }
}