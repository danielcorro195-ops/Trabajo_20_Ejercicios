using System;

class Program
{
    static Random random = new Random();

    // Retorna un mensaje motivacional
    static string mensaje_motivacional()
    {
        string[] mensajes =
        {
            "Cada línea de código te acerca a ser mejor programador.",
            "Los errores son parte del aprendizaje, no te rindas.",
            "La constancia vence al talento cuando el talento no es constante.",
            "Hoy es un gran día para aprender algo nuevo.",
            "Un paso a la vez, así se construyen los grandes proyectos."
        };
        return mensajes[random.Next(mensajes.Length)];
    }

    static void Main()
    {
        Console.WriteLine("Mensaje motivacional: " + mensaje_motivacional());
        Console.WriteLine("\nPresiona una tecla para salir...");
        Console.ReadKey();
    }
}
