using System;

class Program
{
    // Devuelve la fecha actual como cadena (dd/MM/yyyy)
    static string fecha_actual()
    {
        return DateTime.Now.ToString("dd/MM/yyyy");
    }

    static void Main()
    {
        Console.WriteLine("Fecha actual: " + fecha_actual());
        Console.WriteLine("\nPresiona una tecla para salir...");
        Console.ReadKey();
    }
}
