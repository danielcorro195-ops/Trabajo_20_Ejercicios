using System;

class Program
{
    // Devuelve el valor aproximado de PI
    static float obtener_pi()
    {
        return 3.1416f;
    }

    static void Main()
    {
        Console.WriteLine("Valor de PI: " + obtener_pi());
        Console.WriteLine("\nPresiona una tecla para salir...");
        Console.ReadKey();
    }
}
