using System;

class Program
{
    static Random random = new Random();

    // Genera un número aleatorio entre 1 y 100
    static int numero_aleatorio()
    {
        return random.Next(1, 101);
    }

    static void Main()
    {
        Console.WriteLine("Número aleatorio (1-100): " + numero_aleatorio());
        Console.WriteLine("\nPresiona una tecla para salir...");
        Console.ReadKey();
    }
}
