using System;

class Program
{
    // Devuelve el valor aproximado de la constante e
    static float obtener_e()
    {
        return 2.7182f;
    }

    static void Main()
    {
        Console.WriteLine("Valor de e: " + obtener_e());
        Console.WriteLine("\nPresiona una tecla para salir...");
        Console.ReadKey();
    }
}
