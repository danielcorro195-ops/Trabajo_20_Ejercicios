﻿using System;
class Program
{
    static bool es_primo(int numero)
    {
        if (numero < 2)
        {
            return false;
        }

        for (int i = 2; i < numero; i++)
        {
            if (numero % i == 0)
            {
                return false;
            }
        }

        return true;
    }
    static void Main()
    {
        bool resultado = es_primo(7);
        Console.WriteLine(resultado);
    }
}