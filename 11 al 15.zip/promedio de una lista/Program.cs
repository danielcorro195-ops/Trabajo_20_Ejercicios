﻿using System;
using System.Collections.Generic;
class Program
{
    static double promedio(List<int> lista_numeros)
    {
        int suma = 0;

        foreach (int numero in lista_numeros)
        {
            suma += numero;
        }

        return (double)suma / lista_numeros.Count;
    }
    static void Main()
    {
        List<int> numeros = new List<int> { 4, 5, 3, 4 };

        double resultado = promedio(numeros);
        Console.WriteLine("El promedio es: " + resultado);
    }
}