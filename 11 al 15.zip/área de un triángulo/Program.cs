﻿using System;
class Program
{
    static double calcular_area_triangulo(double bas, double altura)
    {
        return (bas * altura) / 2;
    }
    static void Main()
    {
        double area = calcular_area_triangulo(10, 5);
        Console.WriteLine("El area del triangulo es: " + area);
    }
}