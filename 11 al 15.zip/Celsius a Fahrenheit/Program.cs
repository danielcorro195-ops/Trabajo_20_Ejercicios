﻿using System;
class Program
{
    static double celsius_a_fahrenheit(double celsius)
    {
        return (celsius * 9 / 5) + 32;
    }
    static void Main()
    {
        double resultado = celsius_a_fahrenheit(30);
        Console.WriteLine("La temperatura en Fahrenheit es: " + resultado);
    }
}