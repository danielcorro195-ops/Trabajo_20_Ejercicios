﻿using System;
class Program
{
    static int mayor_de_tres(int a, int b, int c)
    {
        int mayor = a;

        if (b > mayor)
        {
            mayor = b;
        }

        if (c > mayor)
        {
            mayor = c;
        }

        return mayor;
    }
    static void Main()
    {
        int resultado = mayor_de_tres(8, 15, 10);
        Console.WriteLine("El numero mayor es: " + resultado);
    }
}