﻿using System;
class Program
{
    static void numeros_pares()
    {
        for (int i = 1; i <= 10; i++)
        {
            Console.WriteLine(i * 2);
        }
    }
    static void Main()
    {
        numeros_pares();
    }
}