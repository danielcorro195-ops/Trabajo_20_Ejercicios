﻿using System;
class Program
{
    static void despedida()
    {
        Console.WriteLine("Gracias por utilizar el programa.");
        Console.WriteLine("Hasta pronto!");
    }
    static void Main()
    {
        despedida();
    }
}