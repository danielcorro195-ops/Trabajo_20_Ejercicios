﻿using System;
class Program
{
    static void mostrar_fecha_hora()
    {
        Console.WriteLine("Fecha y hora actual:");
        Console.WriteLine(DateTime.Now);
    }
    static void Main()
    {
        mostrar_fecha_hora();
    }
}