﻿using System;
class Program
{
    static void mostrar_frutas()
    {
        Console.WriteLine("Manzana");
        Console.WriteLine("Pera");
        Console.WriteLine("Banano");
        Console.WriteLine("Mango");
        Console.WriteLine("Naranja");
    }
    static void Main()
    {
        mostrar_frutas();
    }
}