﻿using System;
class Program
{
    static void mostrar_menu()
    {
        Console.WriteLine("MENU DE OPCIONES");
        Console.WriteLine("1. Registrar");
        Console.WriteLine("2. Consultar");
        Console.WriteLine("3. Modificar");
        Console.WriteLine("4. Salir");
    }
    static void Main()
    {
        mostrar_menu();
    }
}